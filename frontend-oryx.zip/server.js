const express = require('express');
const path = require('path');
const compression = require('compression');

const app = express();
const PORT = process.env.PORT || 8080;

// Enable gzip compression
app.use(compression());

// Serve static files from root with proper MIME types
app.use(express.static(__dirname, {
    maxAge: '1y',
    setHeaders: (res, filePath) => {
        // No cache for HTML
        if (filePath.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache');
        }
        // Set proper Content-Type for JSON
        if (filePath.endsWith('.json')) {
            res.setHeader('Content-Type', 'application/json');
        }
    }
}));

// SPA fallback - ONLY for routes that don't match static files
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`PharmaAssist Frontend running on port ${PORT}`);
});
